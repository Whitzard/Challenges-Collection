interface Result {
    id?: number,
    username?: string,
    message: string
}

export { Result }