<?php
define("WEB_PATH",dirname(__FILE__));
require 'Core/framework.php';